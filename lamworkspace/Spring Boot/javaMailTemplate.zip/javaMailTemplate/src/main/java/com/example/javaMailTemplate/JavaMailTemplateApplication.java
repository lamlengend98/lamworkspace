package com.example.javaMailTemplate;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JavaMailTemplateApplication {

	public static void main(String[] args) {
		SpringApplication.run(JavaMailTemplateApplication.class, args);
	}

}
