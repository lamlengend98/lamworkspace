package com.example.demoJavaMail;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoJavaMailApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoJavaMailApplication.class, args);
	}

}
