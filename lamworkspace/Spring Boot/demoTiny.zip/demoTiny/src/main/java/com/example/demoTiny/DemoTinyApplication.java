package com.example.demoTiny;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoTinyApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoTinyApplication.class, args);
	}

}
